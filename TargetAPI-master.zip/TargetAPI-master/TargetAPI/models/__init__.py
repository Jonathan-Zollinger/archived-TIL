from TargetAPI.models.search_results import Model as SearchResults, Product as SearchProduct
from TargetAPI.models.location_results import ModelItem as Location
from TargetAPI.models.product_availability_online import Model as OnlineAvailabilityResults, \
    Product as OnlineProduct
from TargetAPI.models.product_availability_in_store import Model as StoreAvailabilityResults, \
    Product as StoreProduct, Child as StoreProductChild
